package com.subsysmgr.learnplus.ui.apkbuild;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.shizuku.subsysmgr.R;
import com.shizuku.subsysmgr.databinding.FragmentApkbuildBinding;

import rikka.shizuku.demo.DemoActivity;

public class ApkBuildFragment extends Fragment {

    private FragmentApkbuildBinding binding;

    @SuppressLint("SetJavaScriptEnabled")
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentApkbuildBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final WebView apkbuild = binding.apkbuild;
        final WebView wizard = binding.wizard;
        final WebView aidcode = binding.aidcode;
        final ImageButton code = binding.apkbuildNavCode;
        final ImageButton design = binding.apkbuildNavDesign;
        final ImageButton build = binding.apkbuildNavBuild;
        final ImageButton install = binding.apkbuildNavInstall;

        apkbuild.setVisibility(View.GONE);
        wizard.setVisibility(View.GONE);
        code.setVisibility(View.VISIBLE);

        apkbuild.getSettings().setJavaScriptEnabled(true);
        apkbuild.getSettings().setDatabaseEnabled(true);
        apkbuild.getSettings().setDomStorageEnabled(true);
        apkbuild.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
        apkbuild.getSettings().setUseWideViewPort(true);
        apkbuild.getSettings().setLoadWithOverviewMode(true);
        apkbuild.getSettings().setSupportZoom(true);
        apkbuild.getSettings().setBuiltInZoomControls(true);
        apkbuild.getSettings().setDisplayZoomControls(false);
        apkbuild.getSettings().setAppCacheEnabled(true);
        apkbuild.requestFocus();
        apkbuild.setWebViewClient(new WebViewClient());
        String apkbuild_url = getString(R.string.apkbuild);
        apkbuild.loadUrl(apkbuild_url);

        wizard.getSettings().setJavaScriptEnabled(true);
        wizard.getSettings().setDatabaseEnabled(true);
        wizard.getSettings().setDomStorageEnabled(true);
        wizard.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
        wizard.getSettings().setUseWideViewPort(true);
        wizard.getSettings().setLoadWithOverviewMode(true);
        wizard.getSettings().setSupportZoom(true);
        wizard.getSettings().setBuiltInZoomControls(true);
        wizard.getSettings().setDisplayZoomControls(false);
        wizard.getSettings().setAppCacheEnabled(true);
        wizard.requestFocus();
        wizard.setWebViewClient(new WebViewClient());
        String wizard_url = getString(R.string.wizard);
        wizard.loadUrl(wizard_url);

        aidcode.getSettings().setJavaScriptEnabled(true);
        aidcode.getSettings().setDatabaseEnabled(true);
        aidcode.getSettings().setDomStorageEnabled(true);
        aidcode.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
        aidcode.getSettings().setUseWideViewPort(true);
        aidcode.getSettings().setLoadWithOverviewMode(true);
        aidcode.getSettings().setSupportZoom(true);
        aidcode.getSettings().setBuiltInZoomControls(true);
        aidcode.getSettings().setDisplayZoomControls(false);
        aidcode.getSettings().setAppCacheEnabled(true);
        aidcode.requestFocus();
        aidcode.setWebViewClient(new WebViewClient());
        String aidcode_url = getString(R.string.aidcode);
        aidcode.loadUrl(aidcode_url);

        code.setOnClickListener(v -> code());
        design.setOnClickListener(v -> design());
        build.setOnClickListener(v -> build());
        install.setOnClickListener(v -> install());

        return root;
    }

    private void code() {
        final WebView apkbuild = binding.apkbuild;
        final WebView wizard = binding.wizard;
        final WebView aidcode = binding.aidcode;
        apkbuild.setVisibility(View.GONE);
        wizard.setVisibility(View.GONE);
        aidcode.setVisibility(View.VISIBLE);
    }

    private void design() {
        final WebView apkbuild = binding.apkbuild;
        final WebView wizard = binding.wizard;
        final WebView aidcode = binding.aidcode;
        apkbuild.setVisibility(View.GONE);
        wizard.setVisibility(View.VISIBLE);
        aidcode.setVisibility(View.GONE);
    }

    private void build() {
        final WebView apkbuild = binding.apkbuild;
        final WebView wizard = binding.wizard;
        final WebView aidcode = binding.aidcode;
        apkbuild.setVisibility(View.VISIBLE);
        wizard.setVisibility(View.GONE);
        aidcode.setVisibility(View.GONE);
    }

    private void install() {
        Intent intent = new Intent(getActivity(), DemoActivity.class);
        intent.putExtra("intent", "install_apk_s");
        startActivity(intent);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
