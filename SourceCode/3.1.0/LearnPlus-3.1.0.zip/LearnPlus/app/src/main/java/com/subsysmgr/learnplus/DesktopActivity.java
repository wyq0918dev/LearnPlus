package com.subsysmgr.learnplus;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.learnplus.R;

public class DesktopActivity extends AppCompatActivity {

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_desktop);
        getWindow().setNavigationBarColor(getResources().getColor(R.color.purple_500));

        WebView webView = findViewById(R.id.desktop);
        Toolbar toolbar = findViewById(R.id.toolbar);
        ImageButton keyboard = findViewById(R.id.imageButton_tools_keyboard);
        ImageButton reload = findViewById(R.id.imageButton_tools_reload);
        ImageButton fullscreen = findViewById(R.id.imageButton_tools_fullscreen);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
        webView.getSettings().setUseWideViewPort(true);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setSupportZoom(true);
        webView.getSettings().setBuiltInZoomControls(true);
        webView.getSettings().setDisplayZoomControls(false);
        webView.getSettings().setAppCacheEnabled(true);
        webView.requestFocus();
        webView.setWebViewClient(new WebViewClient());

        keyboard.setOnClickListener(v -> {
            InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            inputMethodManager.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);
        });

        reload.setOnClickListener(v -> webView.reload());

        fullscreen.setOnClickListener(v -> {
            Intent fullscreen1 = new Intent(DesktopActivity.this, WebViewActivity.class);
            String webUrl = webView.getUrl();
            fullscreen1.putExtra("url", webUrl);
            startActivity(fullscreen1);
        });

        Intent desktop = getIntent();
        Intent title = getIntent();
        String intent_url = desktop.getStringExtra("url");
        String toolbar_title = title.getStringExtra("title");
        webView.loadUrl(intent_url);
        toolbar.setNavigationOnClickListener(v -> finish());
        toolbar.setTitle(toolbar_title);
    }
}