package com.subsysmgr.learnplus.page.dashboard;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.android.settings.applications.DeviceInfoActivity;

import com.learnplus.R;
import com.learnplus.databinding.FragmentDashboardBinding;

public class DashboardFragment extends Fragment {

    private FragmentDashboardBinding binding;

    @SuppressLint("UseSwitchCompatOrMaterialCode")
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentDashboardBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final Switch switch_status = binding.switchStatus;
        final TextView textView_status = binding.textViewStatus;
        final TextView shizuku_version = binding.shizukuVersion;
        final TextView ic_manufacturer = binding.icManufacturer;
        final TextView cpu = binding.cpu;
        final CardView device = binding.device;
        final CardView subsysmgr = binding.subsysmgr;
        final ImageView imageView_status = binding.imageViewStatus;

        device.setOnClickListener(v -> startActivity(new Intent(getActivity(), DeviceInfoActivity.class)));
        subsysmgr.setOnClickListener(v -> NavHostFragment.findNavController(DashboardFragment.this).navigate(R.id.action_nav_dashboard_to_nav_manager));

        switch_status.setChecked(true);
        switch_status.setSwitchTextAppearance(getActivity(), R.style.s_false);
        switch_status.setOnCheckedChangeListener((compoundButton, b) -> {
            if (b) {
                switch_status.setSwitchTextAppearance(getActivity(), R.style.s_true);
            } else {
                switch_status.setSwitchTextAppearance(getActivity(), R.style.s_false);
            }
        });
        switch_status.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                textView_status.setText(R.string.lp_framework_active);
                shizuku_version.setText(R.string.shizuku_version);
                ic_manufacturer.setText(R.string.manufacturer);
                cpu.setText(R.string.cpu);
                textView_status.setTextColor(getResources().getColor(R.color.darker_green));
                imageView_status.setBackgroundColor(getResources().getColor(R.color.darker_green));
                imageView_status.setImageResource(R.drawable.ic_baseline_check_circle_outline_24);

            } else {
                textView_status.setText(R.string.lp_framework_not_activated);
                shizuku_version.setText(R.string.unknow);
                ic_manufacturer.setText(R.string.unknow);
                cpu.setText(R.string.unknow);
                textView_status.setTextColor(getResources().getColor(R.color.amber_500));
                imageView_status.setBackgroundColor(getResources().getColor(R.color.amber_500));
                imageView_status.setImageResource(R.drawable.ic_baseline_error_24);
            }
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}