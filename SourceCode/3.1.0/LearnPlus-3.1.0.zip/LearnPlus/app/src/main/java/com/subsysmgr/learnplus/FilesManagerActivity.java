package com.subsysmgr.learnplus;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import com.android.documentsui.files.FilesMainActivity;
import com.android.documentsui.files.OpenFilesActivity;

public class FilesManagerActivity extends AppCompatActivity {

    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startActivity(new Intent(FilesManagerActivity.this, FilesMainActivity.class));
        } else {
            startActivity(new Intent(FilesManagerActivity.this, OpenFilesActivity.class));
        }
        finish();
    }
}