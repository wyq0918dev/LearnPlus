package com.subsysmgr.learnplus.page.webview;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.learnplus.R;
import com.learnplus.databinding.FragmentWebviewBinding;
import com.subsysmgr.learnplus.WebViewActivity;

public class WebViewFragment extends Fragment {

    private FragmentWebviewBinding binding;

    @SuppressLint("SetJavaScriptEnabled")
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentWebviewBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final WebView webView = binding.webviewWeb;
        final EditText editText = binding.editTextUrl;
        final Button go = binding.buttonGo;
        final ImageButton finish = binding.imageButtonToolsFinish;
        final ImageButton back = binding.imageButtonToolsBack;
        final ImageButton forward = binding.imageButtonToolsForward;
        final ImageButton reload = binding.imageButtonToolsReload;
        final ImageButton aidlux = binding.imageButtonToolsAidlux;
        final ImageButton fullscreen = binding.imageButtonToolsFullscreen;

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
        webView.getSettings().setUseWideViewPort(true);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setSupportZoom(true);
        webView.getSettings().setBuiltInZoomControls(true);
        webView.getSettings().setDisplayZoomControls(false);
        webView.getSettings().setAppCacheEnabled(true);
        webView.requestFocus();
        webView.setWebViewClient(new WebViewClient());
        String web = getString(R.string.browser);
        webView.loadUrl(web);

        editText.setText(webView.getUrl());

        go.setOnClickListener(v -> {
            String url = editText.getText().toString();
            webView.loadUrl(url);
        });

        webView.setWebViewClient(new WebViewClient(){
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                editText.setText(webView.getUrl());
            }
        });

        finish.setOnClickListener(v -> requireActivity().onBackPressed());
        back.setOnClickListener(v -> webView.goBack());
        forward.setOnClickListener(v -> webView.goForward());
        reload.setOnClickListener(v -> webView.reload());
        String aidlux_url = getString(R.string.aidlux);
        aidlux.setOnClickListener(v -> webView.loadUrl(aidlux_url));
        fullscreen.setOnClickListener(v -> {
            Intent intent_fullscreen = new Intent(getActivity(), WebViewActivity.class);
            String webUrl = webView.getUrl();
            intent_fullscreen.putExtra("url", webUrl);
            startActivity(intent_fullscreen);
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
