package com.subsysmgr.learnplus.page.home;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.learnplus.R;
import com.learnplus.databinding.FragmentHomeBinding;


public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;

    @SuppressLint("SetJavaScriptEnabled")
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final WebView webView = binding.aidluxHome;

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
        webView.getSettings().setUseWideViewPort(true);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setSupportZoom(true);
        webView.getSettings().setBuiltInZoomControls(true);
        webView.getSettings().setDisplayZoomControls(false);
        webView.getSettings().setAppCacheEnabled(true);
        webView.requestFocus();
        webView.setWebViewClient(new WebViewClient());
        String url = getString(R.string.aidlux);
        webView.loadUrl(url);

        //navigation();

        //final ImageView app_files = binding.appFiles;
        //final ImageView app_store = binding.appStore;
        //final ImageView app_google = binding.appGoogle;
        //final ImageView app_launcher = binding.appLauncher;
        //final ImageView app_camera = binding.appCamera;
        //final ImageView app_aidlux = binding.appAidlux;
        //final ImageView imageButton_bottom_apps_files = binding.imageButtonBottomAppsFiles;
        //final ImageView imageButton_bottom_apps_camera = binding.imageButtonBottomAppsCamera;
        //final Button finish = binding.finishButton;
        //final Button home = binding.homeButton;

        //app_files.setOnClickListener(v -> startActivity(new Intent(getActivity(), FilesManagerActivity.class)));
        //app_store.setOnClickListener(v -> startActivity(new Intent(getActivity(), AssetBrowserActivity.class)));
        //app_google.setOnClickListener(v -> startActivity(new Intent(getActivity(), VoiceSearchActivity.class)));
        //app_launcher.setOnClickListener(v -> startActivity(new Intent(getActivity(), com.tumuyan.fixedplay.MainActivity.class)));
        //app_camera.setOnClickListener(v -> startActivity(new Intent(getActivity(), USBCameraActivity.class)));
        //app_aidlux.setOnClickListener(v -> startActivity(new Intent(getActivity(), AidluxActivity.class)));
        //imageButton_bottom_apps_files.setOnClickListener(v -> startActivity(new Intent(getActivity(), FilesManagerActivity.class)));
        //imageButton_bottom_apps_camera.setOnClickListener(v -> startActivity(new Intent(getActivity(), USBCameraActivity.class)));
        //finish.setOnClickListener(v -> requireActivity().finish());
        //home.setOnClickListener(v -> startActivity(new Intent(getActivity(), MainActivity.class)));

        return root;
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //final ImageView app = binding.appApps;
        //final ImageView imagebutton_bottom_apps_terminal = binding.imageButtonBottomAppsTerminal;
        //final ImageView imageButton_bottom_apps_apps = binding.imageButtonBottomAppsApps;
        //final ImageView webview = binding.imageButtonBottomAppsWebview;
        //final ImageView settings = binding.appSettings;
        //final Button mgr = binding.mgrButton;
        //app.setOnClickListener(v -> NavHostFragment.findNavController(HomeFragment.this).navigate(R.id.action_nav_home_to_nav_application));
        //imagebutton_bottom_apps_terminal.setOnClickListener(v -> NavHostFragment.findNavController(HomeFragment.this).navigate(R.id.action_nav_home_to_nav_terminal));
        //webview.setOnClickListener(v -> NavHostFragment.findNavController(HomeFragment.this).navigate(R.id.action_nav_home_to_nav_webview));
        //settings.setOnClickListener(v -> NavHostFragment.findNavController(HomeFragment.this).navigate(R.id.action_nav_home_to_nav_apps_settings));
       // imageButton_bottom_apps_apps.setOnClickListener(v -> NavHostFragment.findNavController(HomeFragment.this).navigate(R.id.action_nav_home_to_nav_application));
       // mgr.setOnClickListener(v -> NavHostFragment.findNavController(HomeFragment.this).navigate(R.id.action_nav_home_to_nav_dashboard));
    }

    private void navigation() {
        //final FrameLayout navigation = binding.navigation;
        //final ImageView background = binding.imageViewBackground;
        //navigation.setVisibility(View.GONE);
        //background.setOnClickListener(v -> {
        //    if (navigation.getVisibility() == View.GONE) {
        //        navigation.setVisibility(View.VISIBLE);
        //    } else {
        //        navigation.setVisibility(View.GONE);
        //    }
        //});
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}