package com.tumuyan.fixedplay.App;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.ProgressBar;

import androidx.appcompat.widget.Toolbar;

import com.learnplus.R;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class SelectOne extends Activity {

    private List<Item> list = new ArrayList<>();
    private ListView listView;
    private ProgressBar progressBar;
    private String _mode, _action, _uri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.applist_activity);
        getWindow().setNavigationBarColor(getColor(R.color.purple_500));
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        Intent intent = getIntent();
        _mode = intent.getStringExtra("_mode");
        _action = intent.getStringExtra("_action");
        _uri = intent.getStringExtra("_uri");

        new Thread(new Runnable() {
            @Override
            public void run() {
                loadAllApps(makeIntent());
                final ItemAdapter itemAdapter = new ItemAdapter(SelectOne.this, R.layout.applist_item, list);
                itemAdapter.setMode(_mode);
                itemAdapter.setUri(_uri);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        listView = (ListView) findViewById(R.id.listview);
                        if (listView == null) Log.e("listitem", "null");
                        listView.setAdapter(itemAdapter);
                        progressBar.setVisibility(View.GONE);
                    }
                });
            }
        }).start();

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        this.finish();
    }

    private void loadAllApps(Intent intent) {
        List<ResolveInfo> mApps;
        mApps = new ArrayList<>();
        try {
            mApps.addAll(this.getPackageManager().queryIntentActivities(intent, 0));
            PackageManager pm = getPackageManager();
            for (ResolveInfo r : mApps) {
                Item item = new Item(
                        r.loadLabel(pm).toString(),
                        r.activityInfo.packageName,
                        r.activityInfo.name,
                        r.loadIcon(pm)
                );
                list.add(item);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressLint("WrongConstant")
    private Intent makeIntent() {
        switch (_mode) {
            case "r2":
            case "r1":
                Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
                mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);
                return mainIntent;
            case "uri": {
                Uri uri = Uri.parse(_uri);
                Intent it = new Intent(Intent.ACTION_VIEW, uri);
                return it;
            }
            case "uri_dail": {
                Uri uri = Uri.parse(_uri);
                Intent it = new Intent(Intent.ACTION_DIAL, uri);
                return it;
            }
            case "uri_file": {
                File f = (new File(_uri));
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                intent.setDataAndType(Uri.fromFile(f), "*/*");
                return intent;
            }
        }
        return null;
    }
}