package com.tumuyan.fixedplay;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;

import com.android.settings.applications.DefaultAppSelectionActivity;
import com.shizuku.subsysmgr.R;
import com.tumuyan.fixedplay.App.SelectOne;

public class SettingActivity extends Activity {
    PackageManager packageManager;
    String mode = "r2";
    String _mode = "";
    String _uri = "";
    String _action = "";
    String _data = "";

    int _intent_type = 0;

    TextView Text_PackageName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        //导航栏着色，紫色500
        getWindow().setNavigationBarColor(getColor(R.color.purple_500));

        packageManager = getPackageManager();
        Text_PackageName = findViewById(R.id.text_pakageName);

        //接收选择应用企图，并执行相应事件
        Intent intent = getIntent();
        String setting = intent.getStringExtra("setting");
        if (setting == null) {
            Toast.makeText(getApplicationContext(), R.string.intent_null, Toast.LENGTH_SHORT).show();
        } else if (setting.equals("select_app")) {
            button2();
        } else {
            Toast.makeText(getApplicationContext(), R.string.intent_unknown, Toast.LENGTH_SHORT).show();
        }

        go();

        final Button button2 = findViewById(R.id.button2);
        button2.setOnClickListener(view -> button2());

        final Button button1 = findViewById(R.id.button1);
        button1.setOnClickListener(v -> startActivity(new Intent(SettingActivity.this, DefaultAppSelectionActivity.class)));

        //Toolbar返回
        final Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());
    }

    @SuppressLint("SdCardPath")
    private void button2() {
        final String[] items3 = new String[]{"优先从后台切换到前台", "每次都重新打开应用Activity", "浏览网页", "打开地图", "拨打电话", "打开文件"};//创建item
        AlertDialog alertDialog3 = new AlertDialog.Builder(SettingActivity.this)
                .setTitle("选择工作模式")
                .setIcon(R.mipmap.ic_launcher_subsysmgr_logo)
                .setItems(items3, (dialogInterface, i) -> {
                    _mode = "";
                    _uri = "";
                    _action = "";
                    _data = "";
                    _intent_type = i;
                    Intent select = new Intent(SettingActivity.this, SelectOne.class);
                    switch (i) {
                        case 0:
                            _mode = "r2";
                            select.putExtra("_mode", _mode);
                            startActivity(select);
                            break;
                        case 1:
                            _mode = "r1";
                            select.putExtra("_mode", _mode);
                            startActivity(select);
                            break;
                        case 2:
                            _mode = "uri";
                            inputUri("网址链接", "http://m.baidu.com", "");
                            break;
                        case 3:
                            _mode = "uri";
                            inputUri("地图坐标", "geo:38.899533,-77.036476", "geo:");
                            break;
                        case 4:
                            _mode = "uri_dail";
                            inputUri("电话号码", "tel:10086", "tel:");
                            break;
                        case 5:
                            _mode = "uri_file";
                            inputUri("文件路径", "/sdcard/logs.txt", "");
                            break;
                    }
                })
                .create();
        alertDialog3.show();
    }

    public void inputUri(String title, String hint, final String prefix) {
        final EditText inputServer = new EditText(SettingActivity.this);
        inputServer.setHint(hint);
        final String fix;
        if (prefix == null) {
            fix = "";
        } else {
            fix = prefix.toLowerCase();
        }
        final AlertDialog.Builder builder = new AlertDialog.Builder(SettingActivity.this);
        builder.setTitle(title).
                setIcon(android.R.drawable.ic_dialog_info).
                setView(inputServer).
                setNegativeButton("取消", (dialog, which) -> dialog.dismiss());
        builder.setPositiveButton("确定", (dialog, which) -> {
                    _uri = inputServer.getText().toString().toLowerCase();
                    Log.w("_uri", _uri);
                    if (_uri.length() > 0) {
                        String _sub_uri = _uri.substring(0, fix.length());
                        if (_sub_uri.equals(prefix)) {
                            _uri = fix + _uri.substring(fix.length());
                        } else {
                            _uri = fix + _uri;
                        }
                        Intent select = new Intent(SettingActivity.this, SelectOne.class);
                        select.putExtra("_mode", _mode);
                        select.putExtra("_uri", _uri);
                        startActivity(select);
                    }
                }
        );
        builder.show();
    }

    @Override
    public void onResume() {
        super.onResume();
        go();
    }

    @SuppressLint("SetTextI18n")
    public void go() {
        SharedPreferences read = getSharedPreferences("setting", MODE_MULTI_PROCESS);
        final String app = read.getString("app", "");
        if (app.length() < 1) return;

        mode = read.getString("mode", "r2");
        final String label = read.getString("label", "");
        final String uri = read.getString("uri", "");
        final String className = read.getString("class", "");
        final Drawable icon;
        try {
            ApplicationInfo appInfo = packageManager.getApplicationInfo(app, 0);
            icon = (appInfo.loadIcon(packageManager));
            runOnUiThread(() -> {
                Text_PackageName.setText(label);
                //耗时操作，需要在子线程中完成操作后通知主线程实现UI更新
                ((ImageView) findViewById(R.id.item_img)).setImageDrawable(icon);
                ((TextView) findViewById(R.id.item_text)).setText(app);
                ((TextView) findViewById(R.id.item_packageName)).setText(uri + "\n" + className);
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}