package com.aidlux.usbcamera;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;

public class USBCameraActivity extends AppCompatActivity {

    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ComponentName apk2Component1 = new ComponentName("com.aidlux", "com.aidlux.usbcamera.USBCameraActivity");
        Intent mIntent = new Intent();
        mIntent.addCategory(Intent.CATEGORY_LAUNCHER);
        mIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        mIntent.setComponent(apk2Component1);
        startActivity(mIntent);
        finish();
    }
}