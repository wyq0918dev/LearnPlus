package com.subsysmgr.learnplus.ui.module;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.aidlux.app.AidluxActivity;
import com.android.settings.applications.DeveloperActivity;
import com.shizuku.subsysmgr.R;
import com.shizuku.subsysmgr.databinding.FragmentModuleBinding;

import moe.shizuku.manager.MainActivity;


public class ModuleFragment extends Fragment {

    private FragmentModuleBinding binding;

    @SuppressLint("UseSwitchCompatOrMaterialCode")
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentModuleBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final CardView app_lp = binding.module;
        final CardView app_shizuku = binding.moduleShizuku;
        final CardView app_aidlux = binding.moduleAidlux;
        final CardView app_pro = binding.modulePro;
        final Switch checkbox = binding.checkbox;
        final Switch checkbox_shizuku = binding.checkboxShizuku;
        final Switch checkbox_aidlux = binding.checkboxAidlux;
        final Switch checkbox_pro = binding.checkboxPro;
        final TextView version_name = binding.versionName;
        final TextView version_name_aidlux = binding.versionNameAidlux;
        final TextView version_name_shizuku = binding.versionNameShizuku;
        final TextView version_name_pro = binding.versionNamePro;

        app_lp.setOnClickListener(v -> app_lp());
        app_shizuku.setOnClickListener(v -> app_sizuku());
        app_aidlux.setOnClickListener(v -> app_aidlux());
        app_pro.setOnClickListener(v -> pro());

        checkbox.setChecked(true);
        checkbox.setSwitchTextAppearance(getActivity(), R.style.s_false);
        checkbox.setOnCheckedChangeListener((compoundButton, b) -> {
            if (b) {
                checkbox.setSwitchTextAppearance(getActivity(), R.style.s_true);
            } else {
                checkbox.setSwitchTextAppearance(getActivity(), R.style.s_false);
            }
        });
        checkbox_shizuku.setChecked(true);
        checkbox_shizuku.setSwitchTextAppearance(getActivity(), R.style.s_false);
        checkbox_shizuku.setOnCheckedChangeListener((compoundButton, b) -> {
            if (b) {
                checkbox_shizuku.setSwitchTextAppearance(getActivity(), R.style.s_true);
            } else {
                checkbox_shizuku.setSwitchTextAppearance(getActivity(), R.style.s_false);
            }
        });
        checkbox_aidlux.setChecked(true);
        checkbox_aidlux.setSwitchTextAppearance(getActivity(), R.style.s_false);
        checkbox_aidlux.setOnCheckedChangeListener((compoundButton, b) -> {
            if (b) {
                checkbox_aidlux.setSwitchTextAppearance(getActivity(), R.style.s_true);
            } else {
                checkbox_aidlux.setSwitchTextAppearance(getActivity(), R.style.s_false);
            }
        });
        checkbox_pro.setChecked(true);
        checkbox_pro.setSwitchTextAppearance(getActivity(), R.style.s_false);
        checkbox_pro.setOnCheckedChangeListener((compoundButton, b) -> {
            if (b) {
                checkbox_pro.setSwitchTextAppearance(getActivity(), R.style.s_true);
            } else {
                checkbox_pro.setSwitchTextAppearance(getActivity(), R.style.s_false);
            }
        });

        checkbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                app_lp();
            } else {
                stop();
            }
        });
        checkbox_shizuku.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                app_sizuku();
            } else {
                stop();
            }
        });
        checkbox_aidlux.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                app_aidlux();
            } else {
                stop();
            }
        });
        checkbox_pro.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                pro();
            } else {
                stop();
            }
        });

        String version = getLearnPlusInfo();
        String aidlux_version = getAidLuxInfo();
        String shizuku_version = getShizukuInfo();
        version_name.setText(version);
        version_name_aidlux.setText(aidlux_version);
        version_name_shizuku.setText(shizuku_version);
        version_name_pro.setText(version);

        return root;
    }

    private String getLearnPlusInfo() {
        try {
            String package_name = requireActivity().getPackageName();
            String versionName = requireActivity().getPackageManager().getPackageInfo(package_name, 0).versionName;
            return versionName + "";
        } catch (Exception ignored) {
        }
        return null;
    }

    private String getAidLuxInfo() {
        try {
            String package_name = getString(R.string.aidlux_package);
            String versionName = requireActivity().getPackageManager().getPackageInfo(package_name, 0).versionName;
            return versionName + "";
        } catch (Exception ignored) {
        }
        return null;
    }

    private String getShizukuInfo() {
        try {
            String package_name = getString(R.string.shizuku_package);
            String versionName = requireActivity().getPackageManager().getPackageInfo(package_name, 0).versionName;
            return versionName + "";
        } catch (Exception ignored) {
        }
        return null;
    }

    private void stop() {
        NavHostFragment.findNavController(ModuleFragment.this).navigate(R.id.action_nav_module_to_nav_manager);
    }

    private void app_lp() {
        NavHostFragment.findNavController(ModuleFragment.this).navigate(R.id.action_nav_module_to_nav_apps_launcher);
    }

    private void app_sizuku() {
        startActivity(new Intent(getActivity(), MainActivity.class));
    }

    private void app_aidlux() {
        startActivity(new Intent(getActivity(), AidluxActivity.class));
    }

    private void pro() {
        String module = getString(R.string.module_name);
        String pro = getString(R.string.pro);
        String dev = getString(R.string.developer_settings);
        String ok = getString(R.string.lpp_ok);
        String txt = getString(R.string.lpp_txt);
        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
        builder.setIcon(R.mipmap.ic_launcher_subsysmgr_logo)
                .setTitle(module + pro)
                .setMessage(txt)
                .setPositiveButton(ok, (dialog, which) -> {
                })
                .setNegativeButton(dev, (dialog, which) -> startActivity(new Intent(getActivity(), DeveloperActivity.class)))
                .setCancelable(false)
                .create()
                .show();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}