package com.shizuku.subsysmgr;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.aidlux.app.AidluxActivity;
import com.aidlux.usbcamera.USBCameraActivity;
import com.android.vending.AssetBrowserActivity;
import com.google.android.googlequicksearchbox.VoiceSearchActivity;
import com.subsysmgr.learnplus.FilesManagerActivity;
import com.tumuyan.fixedplay.MainActivity;

import rikka.shizuku.demo.DemoActivity;

public class IntentAPI extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        String string = intent.getStringExtra("str");
        if (string == null) {
            Toast.makeText(getApplicationContext(), R.string.intent_null, Toast.LENGTH_SHORT).show();
            finish();
        } else if (string.equals("manager")) {
            Intent manager = new Intent(IntentAPI.this, DemoActivity.class);
            manager.putExtra("intent", "apps");
            manager.putExtra("page", "manager");
            startActivity(manager);
            finish();
        } else if (string.equals("module")) {
            Intent module = new Intent(IntentAPI.this, DemoActivity.class);
            module.putExtra("intent", "apps");
            module.putExtra("page", "module");
            startActivity(module);
            finish();
        } else if (string.equals("apps")) {
            Intent apps = new Intent(IntentAPI.this, DemoActivity.class);
            apps.putExtra("intent", "apps");
            apps.putExtra("page", "apps");
            startActivity(apps);
            finish();
        } else if (string.equals("launcher")) {
            Intent launcher = new Intent(IntentAPI.this, DemoActivity.class);
            launcher.putExtra("intent", "apps");
            launcher.putExtra("page", "launcher");
            startActivity(launcher);
            finish();
        } else if (string.equals("home")) {
            Intent home = new Intent(IntentAPI.this, DemoActivity.class);
            home.putExtra("intent", "apps");
            home.putExtra("page", "home");
            startActivity(home);
            finish();
        } else if (string.equals("dashboard")) {
            Intent dashboard = new Intent(IntentAPI.this, DemoActivity.class);
            dashboard.putExtra("intent", "apps");
            dashboard.putExtra("page", "dashboard");
            startActivity(dashboard);
            finish();
        } else if (string.equals("terminal")) {
            Intent terminal = new Intent(IntentAPI.this, DemoActivity.class);
            terminal.putExtra("intent", "apps");
            terminal.putExtra("page", "terminal");
            startActivity(terminal);
            finish();
        } else if (string.equals("application")) {
            Intent application = new Intent(IntentAPI.this, DemoActivity.class);
            application.putExtra("intent", "apps");
            application.putExtra("page", "application");
            startActivity(application);
            finish();
        } else if (string.equals("services")) {
            Intent services = new Intent(IntentAPI.this, DemoActivity.class);
            services.putExtra("intent", "apps");
            services.putExtra("page", "services");
            startActivity(services);
            finish();
        } else if (string.equals("webview")) {
            Intent webview = new Intent(IntentAPI.this, DemoActivity.class);
            webview.putExtra("intent", "apps");
            webview.putExtra("page", "webview");
            startActivity(webview);
            finish();
        } else if (string.equals("settings")) {
            Intent settings = new Intent(IntentAPI.this, DemoActivity.class);
            settings.putExtra("intent", "apps");
            settings.putExtra("page", "settings");
            startActivity(settings);
            finish();
        } else if (string.equals("files")) {
            Intent files = new Intent(IntentAPI.this, DemoActivity.class);
            files.putExtra("intent", "apps");
            files.putExtra("page", "files");
            startActivity(files);
            finish();
        } else if (string.equals("vscode")) {
            Intent vscode = new Intent(IntentAPI.this, DemoActivity.class);
            vscode.putExtra("intent", "apps");
            vscode.putExtra("page", "vscode");
            startActivity(vscode);
            finish();
        } else if (string.equals("cloudip")) {
            Intent cloudip = new Intent(IntentAPI.this, DemoActivity.class);
            cloudip.putExtra("intent", "apps");
            cloudip.putExtra("page", "cloudip");
            startActivity(cloudip);
            finish();
        } else if (string.equals("jupyter")) {
            Intent jupyter = new Intent(IntentAPI.this, DemoActivity.class);
            jupyter.putExtra("intent", "apps");
            jupyter.putExtra("page", "jupyter");
            startActivity(jupyter);
            finish();
        } else if (string.equals("aidcode")) {
            Intent aidcode = new Intent(IntentAPI.this, DemoActivity.class);
            aidcode.putExtra("intent", "apps");
            aidcode.putExtra("page", "aidcode");
            startActivity(aidcode);
            finish();
        } else if (string.equals("blockly")) {
            Intent blockly = new Intent(IntentAPI.this, DemoActivity.class);
            blockly.putExtra("intent", "apps");
            blockly.putExtra("page", "blockly");
            startActivity(blockly);
            finish();
        } else if (string.equals("apkbuild")) {
            Intent apkbuild = new Intent(IntentAPI.this, DemoActivity.class);
            apkbuild.putExtra("intent", "apps");
            apkbuild.putExtra("page", "apkbuild");
            startActivity(apkbuild);
            finish();
        } else if (string.equals("examples")) {
            Intent examples = new Intent(IntentAPI.this, DemoActivity.class);
            examples.putExtra("intent", "apps");
            examples.putExtra("page", "examples");
            startActivity(examples);
            finish();
        } else if (string.equals("docs")) {
            Intent docs = new Intent(IntentAPI.this, DemoActivity.class);
            docs.putExtra("intent", "apps");
            docs.putExtra("page", "docs");
            startActivity(docs);
            finish();
        } else if (string.equals("xfce")) {
            Intent docs = new Intent(IntentAPI.this, DemoActivity.class);
            docs.putExtra("intent", "apps");
            docs.putExtra("page", "xfce");
            startActivity(docs);
            finish();
        } else if (string.equals("xmode")) {
            Intent docs = new Intent(IntentAPI.this, DemoActivity.class);
            docs.putExtra("intent", "apps");
            docs.putExtra("page", "xmode");
            startActivity(docs);
            finish();
        } else if (string.equals("synaptic")) {
            Intent docs = new Intent(IntentAPI.this, DemoActivity.class);
            docs.putExtra("intent", "apps");
            docs.putExtra("page", "synaptic");
            startActivity(docs);
            finish();
        } else if (string.equals("xde")) {
            Intent docs = new Intent(IntentAPI.this, DemoActivity.class);
            docs.putExtra("intent", "apps");
            docs.putExtra("page", "xde");
            startActivity(docs);
            finish();
        } else if (string.equals("play")) {
            startActivity(new Intent(IntentAPI.this, AssetBrowserActivity.class));
            finish();
        } else if (string.equals("google")) {
            startActivity(new Intent(IntentAPI.this, VoiceSearchActivity.class));
            finish();
        } else if (string.equals("anylauncher")) {
            startActivity(new Intent(IntentAPI.this, MainActivity.class));
            finish();
        } else if (string.equals("shizuku")) {
            startActivity(new Intent(IntentAPI.this, moe.shizuku.manager.MainActivity.class));
            finish();
        } else if (string.equals("aidlux")) {
            startActivity(new Intent(IntentAPI.this, AidluxActivity.class));
            finish();
        } else if (string.equals("camera")) {
            startActivity(new Intent(IntentAPI.this, USBCameraActivity.class));
            finish();
        } else if (string.equals("document")) {
            startActivity(new Intent(IntentAPI.this, FilesManagerActivity.class));
            finish();
        } else {
            Toast.makeText(getApplicationContext(), R.string.intent_unknown, Toast.LENGTH_SHORT).show();
            finish();
        }
    }
}