package com.subsysmgr.learnplus.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import com.aidlux.app.AidluxActivity;
import com.aidlux.usbcamera.USBCameraActivity;
import com.android.subsysmgr.MainActivity;
import com.android.vending.AssetBrowserActivity;
import com.google.android.googlequicksearchbox.VoiceSearchActivity;
import com.shizuku.subsysmgr.databinding.FragmentHomeBinding;
import com.subsysmgr.learnplus.SettingsActivity;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        //application image button
        final ImageButton mgr_imgbtn = binding.mgrImageButton;
        final ImageButton settings_imgbtn = binding.settingsImageButton;
        final ImageButton store_imgbtn = binding.storeImageButton;
        final ImageButton google_imgbtn = binding.googleImageButton;
        final ImageButton launcher_imgbtn = binding.launcherImageButton;
        final ImageButton camera_imgbtn = binding.cameraImageButton;
        final ImageButton aidlux_imgbtn = binding.aidluxImageButton;
        final ImageButton apps_imgbtn = binding.appsImageButton;

        //toolbar navigation button
        final Toolbar toolbar = binding.navigationToolbar;

        //navigation bar button.
        final Button finish = binding.finishButton;
        final Button home = binding.homeButton;
        final Button mgr = binding.mgrButton;

        //application image button event click
        mgr_imgbtn.setOnClickListener(v -> mgr());
        settings_imgbtn.setOnClickListener(v -> startActivity(new Intent(getActivity(), SettingsActivity.class)));
        store_imgbtn.setOnClickListener(v -> startActivity(new Intent(getActivity(), AssetBrowserActivity.class)));
        google_imgbtn.setOnClickListener(v -> startActivity(new Intent(getActivity(), VoiceSearchActivity.class)));
        launcher_imgbtn.setOnClickListener(v -> launcher());
        camera_imgbtn.setOnClickListener(v -> startActivity(new Intent(getActivity(), USBCameraActivity.class)));
        aidlux_imgbtn.setOnClickListener(v -> startActivity(new Intent(getActivity(), AidluxActivity.class)));
        apps_imgbtn.setOnClickListener(v -> startActivity(new Intent(getActivity(), com.android.launcher3.applications.MainActivity.class)));

        //toolbar navigation button event click
        toolbar.setNavigationOnClickListener(v -> mgr());

        //navigation bar button event click
        finish.setOnClickListener(v -> finish());
        home.setOnClickListener(v -> launcher());
        mgr.setOnClickListener(v -> mgr());

        return root;
    }

    private void finish() {
        //exit
        requireActivity().finish();
    }

    private void launcher() {
        //start launcher
        startActivity(new Intent(getActivity(), com.tumuyan.fixedplay.MainActivity.class));
    }

    private void mgr() {
        //start subsystem manager
        startActivity(new Intent(getActivity(), MainActivity.class));
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}