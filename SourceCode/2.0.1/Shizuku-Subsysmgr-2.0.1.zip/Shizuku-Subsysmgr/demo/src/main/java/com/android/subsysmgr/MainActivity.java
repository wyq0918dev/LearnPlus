package com.android.subsysmgr;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import com.shizuku.subsysmgr.R;
import com.shizuku.subsysmgr.databinding.MainActivityBinding;

import rikka.shizuku.demo.DemoActivity;

public class MainActivity extends AppCompatActivity {

    private MainActivityBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        binding = MainActivityBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        Switch switch_status = findViewById(R.id.switch_status);
        Switch checkbox = findViewById(R.id.checkbox);
        TextView textView_status = findViewById(R.id.textView_status);
        TextView shizuku_version = findViewById(R.id.shizuku_version);
        TextView ic_manufacturer = findViewById(R.id.ic_manufacturer);
        TextView cpu = findViewById(R.id.cpu);
        TextView textView_install_title = findViewById(R.id.textView_install_title);
        View module_view = findViewById(R.id.module);
        View uninstall_view = findViewById(R.id.uninstall);
        ImageButton install = findViewById(R.id.install_imagebutton);
        ImageButton uninatall = findViewById(R.id.uninstall_imagebutton);
        ImageView imageView_status = findViewById(R.id.imageView_status);

        toolbar.setNavigationOnClickListener(v -> finish());
        install.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, DemoActivity.class)));
        uninatall.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, UninstallActivity.class)));
        module_view.setOnClickListener(v -> manager());

        switch_status.setChecked(true);
        switch_status.setSwitchTextAppearance(MainActivity.this, R.style.s_false);
        switch_status.setOnCheckedChangeListener((compoundButton, b) -> {
            if (b) {
                switch_status.setSwitchTextAppearance(MainActivity.this, R.style.s_true);
            } else {
                switch_status.setSwitchTextAppearance(MainActivity.this, R.style.s_false);
            }
        });

        switch_status.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                textView_status.setText(R.string.framework_active);
                shizuku_version.setText(R.string.shizuku_version);
                ic_manufacturer.setText(R.string.manufacturer);
                cpu.setText(R.string.cpu);
                textView_status.setTextColor(getResources().getColor(R.color.darker_green));
                imageView_status.setBackgroundColor(getResources().getColor(R.color.darker_green));
                imageView_status.setImageDrawable(getResources().getDrawable(R.drawable.ic_baseline_check_circle_outline_24));
                module_view.setVisibility(View.VISIBLE);
                textView_install_title.setText(R.string.update);
                uninstall_view.setVisibility(View.VISIBLE);
            } else {
                textView_status.setText(R.string.framework_not_activated);
                shizuku_version.setText(R.string.unknow);
                ic_manufacturer.setText(R.string.unknow);
                cpu.setText(R.string.unknow);
                textView_status.setTextColor(getResources().getColor(R.color.warning));
                imageView_status.setBackgroundColor(getResources().getColor(R.color.warning));
                imageView_status.setImageDrawable(getResources().getDrawable(R.drawable.ic_baseline_warning_24));
                module_view.setVisibility(View.GONE);
                textView_install_title.setText(R.string.install);
                uninstall_view.setVisibility(View.GONE);
            }
        });

        checkbox.setChecked(true);
        checkbox.setSwitchTextAppearance(MainActivity.this, R.style.s_false);
        checkbox.setOnCheckedChangeListener((compoundButton, b) -> {
            if (b) {
                checkbox.setSwitchTextAppearance(MainActivity.this, R.style.s_true);
            } else {
                checkbox.setSwitchTextAppearance(MainActivity.this, R.style.s_false);
            }
        });

        checkbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                manager();
            } else {
                stop();
            }
        });
    }

    private void manager() {
        startActivity(new Intent(MainActivity.this, com.subsysmgr.learnplus.MainActivity.class));
    }

    @SuppressLint("WrongConstant")
    private void stop() {
        finish();
    }
}