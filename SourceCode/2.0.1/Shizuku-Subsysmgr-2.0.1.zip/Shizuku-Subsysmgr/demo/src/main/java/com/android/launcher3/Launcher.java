package com.android.launcher3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.KeyEvent;

import com.tumuyan.fixedplay.MainActivity;

public class Launcher extends AppCompatActivity {

    @Override
    public void onResume(){
        startActivity(new Intent(Launcher.this, MainActivity.class));
        super.onResume();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event){
        if(keyCode==KeyEvent.KEYCODE_BACK){
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}