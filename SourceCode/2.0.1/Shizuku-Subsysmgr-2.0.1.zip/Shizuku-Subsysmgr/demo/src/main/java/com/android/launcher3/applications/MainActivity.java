package com.android.launcher3.applications;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.aidlux.app.AidluxActivity;
import com.aidlux.usbcamera.USBCameraActivity;
import com.android.launcher3.applications.Launcher.AidCode;
import com.android.launcher3.applications.Launcher.Blockly;
import com.android.launcher3.applications.Launcher.Examples;
import com.android.launcher3.applications.Launcher.Finder;
import com.android.launcher3.applications.Launcher.InternetProtocol;
import com.android.launcher3.applications.Launcher.Jupyter;
import com.android.launcher3.applications.Launcher.Synaptic;
import com.android.launcher3.applications.Launcher.Terminal;
import com.android.launcher3.applications.Launcher.VisualStudioCode;
import com.android.launcher3.applications.Launcher.XDesktopEnvironment;
import com.android.launcher3.applications.Launcher.XMode;
import com.android.launcher3.applications.Launcher.XfceDesktopEnvironment;
import com.android.vending.AssetBrowserActivity;
import com.google.android.googlequicksearchbox.VoiceSearchActivity;
import com.shizuku.subsysmgr.R;
import com.subsysmgr.learnplus.FilesActivity;
import com.subsysmgr.learnplus.SettingsActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apps_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        ImageButton manager = findViewById(R.id.manager_imageButton);
        ImageButton settings = findViewById(R.id.settings_imageButton);
        ImageButton store = findViewById(R.id.store_imageButton);
        ImageButton camera = findViewById(R.id.camera_imageButton);
        ImageButton launcher = findViewById(R.id.launcher_imageButton);
        ImageButton google = findViewById(R.id.google_imageButton);
        ImageButton files = findViewById(R.id.files_imageButton);
        ImageButton aidlux = findViewById(R.id.aidlux_imageButton);
        ImageButton xfce = findViewById(R.id.xfce_imageButton);
        ImageButton xmode = findViewById(R.id.xmode_imageButton);
        ImageButton Synaptic = findViewById(R.id.synaptic_imageButton);
        ImageButton xde = findViewById(R.id.xde_imageButton);
        ImageButton vscode = findViewById(R.id.vscode_imageButton);
        ImageButton terminal = findViewById(R.id.terminal_imageButton);
        ImageButton cloudip = findViewById(R.id.ip_imageButton);
        ImageButton finder = findViewById(R.id.finder_imageButton);
        ImageButton jupyter = findViewById(R.id.jupyter_imageButton);
        ImageButton aidcode = findViewById(R.id.aidcode_imageButton);
        ImageButton blockly = findViewById(R.id.blockly_imageButton);
        ImageButton examples = findViewById(R.id.examples_imageButton);

        toolbar.setNavigationOnClickListener(v -> finish());
        manager.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, com.android.subsysmgr.MainActivity.class)));
        settings.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, SettingsActivity.class)));
        store.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, AssetBrowserActivity.class)));
        camera.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, USBCameraActivity.class)));
        launcher.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, com.tumuyan.fixedplay.MainActivity.class)));
        google.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, VoiceSearchActivity.class)));
        files.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, FilesActivity.class)));
        aidlux.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, AidluxActivity.class)));
        xfce.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, XfceDesktopEnvironment.class)));
        xmode.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, XMode.class)));
        Synaptic.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, Synaptic.class)));
        xde.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, XDesktopEnvironment.class)));
        vscode.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, VisualStudioCode.class)));
        terminal.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, Terminal.class)));
        cloudip.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, InternetProtocol.class)));
        finder.setOnClickListener(v -> startActivity(new Intent( MainActivity.this, Finder.class)));
        jupyter.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, Jupyter.class)));
        aidcode.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, AidCode.class)));
        blockly.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, Blockly.class)));
        examples.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, Examples.class)));
    }
}