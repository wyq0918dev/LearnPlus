package com.tumuyan.fixedplay;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

import com.shizuku.subsysmgr.R;

import java.io.File;

public class MainActivity extends Activity {

    PackageManager packageManager;
    final String THIS_PACKAGE = "com.shizuku.subsysmgr";
    String mode = "r2";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        packageManager = getPackageManager();
        getWindow().setNavigationBarColor(getColor(R.color.purple_500));
        Log.w("MainActivity", "Create");
        go();
        finish();
    }

    @SuppressLint("WrongConstant")
    public void go() {
        SharedPreferences read = getSharedPreferences("setting", MODE_MULTI_PROCESS);
        String app = read.getString("app", "");
        String claseName = read.getString("class", "");
        String uri = read.getString("uri", "");
        mode = read.getString("mode", "r2");
        Log.w("MainActivity mode", mode + "\n packagename: " + app);
        if (app.length() > 0 && app != THIS_PACKAGE) {
            switch (mode) {
                case "r2": {
                    Log.w("MainActivity mode2", mode);
                    Intent intent = packageManager.getLaunchIntentForPackage(app);
                    if (intent != null) startActivity(intent);
                    break;
                }
                case "r1":
                    if (claseName.length() > 5) {
                        Intent intent = new Intent();
                        intent.setClassName(app, claseName);
                        startActivity(intent);
                    } else {
                        //   Log.w("MainActivity mode1" ,mode);
                        Intent intent = new Intent();
                        intent = packageManager.getLaunchIntentForPackage(app);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        this.startActivity(intent);
                    }
                    break;
                case "uri": {
                    Uri u = Uri.parse(uri);
                    Intent intent = new Intent(Intent.ACTION_VIEW, u);
                    if (claseName.length() > 0) {
                        intent.setClassName(app, claseName);
                    } else {
                        intent.setPackage(app);
                    }
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    break;
                }
                case "uri_dail": {
                    Uri u = Uri.parse(uri);
                    Intent intent = new Intent(Intent.ACTION_DIAL, u);
                    if (claseName.length() > 0) {
                        intent.setClassName(app, claseName);
                    } else {
                        intent.setPackage(app);
                    }
                    startActivity(intent);
                    break;
                }
                case "uri_file": {
                    Intent intent = new Intent("android.intent.action.VIEW");
                    intent.addCategory("android.intent.category.DEFAULT");
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    if (claseName.length() > 0) {
                        intent.setClassName(app, claseName);
                    } else {
                        intent.setPackage(app);
                    }
                    Uri u = Uri.fromFile(new File(uri));
                    intent.setDataAndType(u, "*/*");
                    startActivity(intent);
                    break;
                }
            }
        } else {
            Intent intent = new Intent(MainActivity.this, SettingActivity.class);
            startActivity(intent);
        }
    }
}