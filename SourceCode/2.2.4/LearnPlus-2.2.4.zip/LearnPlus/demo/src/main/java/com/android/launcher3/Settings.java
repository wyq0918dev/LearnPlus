package com.android.launcher3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import rikka.shizuku.demo.DemoActivity;

public class Settings extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = new Intent(Settings.this, DemoActivity.class);
        intent.putExtra("intent","apps");
        intent.putExtra("page", "settings");
        startActivity(intent);
        finish();
    }
}