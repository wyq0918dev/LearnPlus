package com.subsysmgr.learnplus.ui.apps;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.android.subsysmgr.UninstallActivity;
import com.shizuku.subsysmgr.R;
import com.shizuku.subsysmgr.databinding.FragmentAppsBinding;

import rikka.shizuku.demo.DemoActivity;

public class AppsFragment extends Fragment {

    private FragmentAppsBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentAppsBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        final CardView uninstall_view = binding.uninstall;
        final CardView install_view = binding.install;
        uninstall_view.setOnClickListener(v -> startActivity(new Intent(getActivity(), UninstallActivity.class)));
        install_view.setOnClickListener(v -> {
            Intent install = new Intent(getActivity(), DemoActivity.class);
            install.putExtra("intent","install_apk_s");
            startActivity(install);
        });
        return root;
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        final CardView app = binding.application;
        final CardView settings = binding.settings;
        app.setOnClickListener(v -> NavHostFragment.findNavController(AppsFragment.this).navigate(R.id.action_nav_apps_to_nav_apps_launcher));
        settings.setOnClickListener(v -> NavHostFragment.findNavController(AppsFragment.this).navigate(R.id.action_nav_apps_to_nav_apps_settings));
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}