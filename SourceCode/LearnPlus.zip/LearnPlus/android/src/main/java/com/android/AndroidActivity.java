package com.android;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.android.camera2.CameraActivity;
import com.android.contacts.activities.PeopleActivity;
import com.android.dialer.main.impl.DialtactsActivity;
import com.android.documentsui.files.FilesMainActivity;
import com.android.settings.applications.DefaultHomeSelectionActivity;
import com.android.settings.applications.DeviceInfoActivity;
import com.android.settings.system.Settings;
import com.android.uninstall.UninstallActivity;

public class AndroidActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        String string = intent.getStringExtra("android");
        if (string != null) {
            switch (string) {
                case "camera":
                    startActivity(new Intent(AndroidActivity.this, CameraActivity.class));
                    break;
                case "contacts":
                    startActivity(new Intent(AndroidActivity.this, PeopleActivity.class));
                    break;
                case "dialer":
                    startActivity(new Intent(AndroidActivity.this, DialtactsActivity.class));
                    break;
                case "documents":
                    startActivity(new Intent(AndroidActivity.this, FilesMainActivity.class));
                    break;
                case "google":
                    //Intent intent_google = new Intent(AndroidActivity.this, GrantFakeSignaturePermissionActivity.class);
                    //intent_google.putExtra("micro", "google_search");
                    //startActivity(intent_google);
                    break;
                case "microg":
                    //Intent intent_microg = new Intent(AndroidActivity.this, GrantFakeSignaturePermissionActivity.class);
                    //intent_microg.putExtra("micro", "grant_fake_signature_permission");
                    //startActivity(intent_microg);
                    break;
                case "play":
                    //Intent intent_play = new Intent(AndroidActivity.this, GrantFakeSignaturePermissionActivity.class);
                    //intent_play.putExtra("micro", "google_play_store");
                    //startActivity(intent_play);
                    break;
                case "settings":
                    String settings = intent.getStringExtra("settings");
                    if (settings != null){
                        switch (settings){
                            case "system":
                                startActivity(new Intent(AndroidActivity.this, Settings.class));
                                break;
                            case "default_home":
                                startActivity(new Intent(AndroidActivity.this, DefaultHomeSelectionActivity.class));
                                break;
                            case "device_info":
                                startActivity(new Intent(AndroidActivity.this, DeviceInfoActivity.class));
                                break;
                            default:
                                //Toast.makeText(getApplicationContext(), R.string.intent_unknown, Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        //Toast.makeText(getApplicationContext(), R.string.intent_null, Toast.LENGTH_SHORT).show();
                    }
                    break;
                case "uninstall":
                    startActivity(new Intent(AndroidActivity.this, UninstallActivity.class));
                    break;
                default:
                    //Toast.makeText(getApplicationContext(), R.string.intent_unknown, Toast.LENGTH_SHORT).show();
            }
        } else {
            //Toast.makeText(getApplicationContext(), R.string.intent_null, Toast.LENGTH_SHORT).show();
        }
        finish();
    }
}