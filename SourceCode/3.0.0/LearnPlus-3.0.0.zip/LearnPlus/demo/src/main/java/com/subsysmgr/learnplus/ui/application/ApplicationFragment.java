package com.subsysmgr.learnplus.ui.application;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.aidlux.app.AidluxActivity;
import com.aidlux.usbcamera.USBCameraActivity;
import com.android.vending.AssetBrowserActivity;
import com.google.android.googlequicksearchbox.VoiceSearchActivity;
import com.shizuku.subsysmgr.IntentAPI;
import com.shizuku.subsysmgr.R;
import com.shizuku.subsysmgr.databinding.FragmentApplicationBinding;
import com.subsysmgr.learnplus.DesktopActivity;
import com.subsysmgr.learnplus.FilesManagerActivity;

import rikka.shizuku.demo.DemoActivity;

public class ApplicationFragment extends Fragment {

    private FragmentApplicationBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentApplicationBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final ImageButton store = binding.storeImageButton;
        final ImageButton camera = binding.cameraImageButton;
        final ImageButton launcher = binding.launcherImageButton;
        final ImageButton google = binding.googleImageButton;
        final ImageButton aidlux = binding.aidluxImageButton;
        final ImageButton files = binding.filesImageButton;
        final ImageButton shizuku = binding.shizukuImageButton;
        final ImageButton xfce = binding.xfceImageButton;

        store.setOnClickListener(v -> startActivity(new Intent(getActivity(), AssetBrowserActivity.class)));
        camera.setOnClickListener(v -> startActivity(new Intent(getActivity(), USBCameraActivity.class)));
        launcher.setOnClickListener(v -> startActivity(new Intent(getActivity(), com.tumuyan.fixedplay.MainActivity.class)));
        google.setOnClickListener(v -> startActivity(new Intent(getActivity(), VoiceSearchActivity.class)));
        aidlux.setOnClickListener(v -> startActivity(new Intent(getActivity(), AidluxActivity.class)));
        files.setOnClickListener(v -> startActivity(new Intent(getActivity(), FilesManagerActivity.class)));
        shizuku.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), DemoActivity.class);
            intent.putExtra("intent", "shizuku");
            startActivity(intent);
        });

        xfce.setOnClickListener(v -> {
            String url = getString(R.string.xfce);
            String title = getString(R.string.app_xfce);
            Intent intent_xfce = new Intent(getActivity(), DesktopActivity.class);
            intent_xfce.putExtra("url", url);
            intent_xfce.putExtra("title", title);
            startActivity(intent_xfce);
        });

        return root;
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        final ImageButton manager = binding.managerImageButton;
        final ImageButton settings = binding.settingsImageButton;
        final ImageButton chromium = binding.chromiumImageButton;
        final ImageButton terminal_app = binding.terminalAppImageButton;
        final ImageButton dashboard = binding.dashboardImageButton;
        final ImageButton vscode = binding.vscodeImageButton;
        final ImageButton terminal = binding.terminalImageButton;
        final ImageButton ip = binding.ipImageButton;
        final ImageButton finder = binding.finderImageButton;
        final ImageButton jupyter = binding.jupyterImageButton;
        final ImageButton aidcode = binding.aidcodeImageButton;
        final ImageButton blockly = binding.blocklyImageButton;
        final ImageButton apkbuild = binding.apkbuildImageButton;
        final ImageButton docs = binding.docsImageButton;
        final ImageButton examples = binding.examplesImageButton;
        manager.setOnClickListener(v -> NavHostFragment.findNavController(ApplicationFragment.this).navigate(R.id.action_nav_application_to_nav_manager));
        settings.setOnClickListener(v -> NavHostFragment.findNavController(ApplicationFragment.this).navigate(R.id.action_nav_application_to_nav_apps_settings));
        chromium.setOnClickListener(v -> NavHostFragment.findNavController(ApplicationFragment.this).navigate(R.id.action_nav_application_to_nav_webview));
        terminal_app.setOnClickListener(v -> NavHostFragment.findNavController(ApplicationFragment.this).navigate(R.id.action_nav_application_to_nav_terminal));
        dashboard.setOnClickListener(v -> NavHostFragment.findNavController(ApplicationFragment.this).navigate(R.id.action_nav_application_to_nav_dashboard));
        vscode.setOnClickListener(v -> NavHostFragment.findNavController(ApplicationFragment.this).navigate(R.id.action_nav_application_to_nav_vscode));
        ip.setOnClickListener(v -> NavHostFragment.findNavController(ApplicationFragment.this).navigate(R.id.action_nav_application_to_nav_cloudip));
        terminal.setOnClickListener(v -> NavHostFragment.findNavController(ApplicationFragment.this).navigate(R.id.action_nav_application_to_nav_terminal));
        finder.setOnClickListener(v -> NavHostFragment.findNavController(ApplicationFragment.this).navigate(R.id.action_nav_application_to_nav_apps_files));
        jupyter.setOnClickListener(v -> NavHostFragment.findNavController(ApplicationFragment.this).navigate(R.id.action_nav_application_to_nav_jupyter));
        aidcode.setOnClickListener(v -> NavHostFragment.findNavController(ApplicationFragment.this).navigate(R.id.action_nav_application_to_nav_aidcode));
        blockly.setOnClickListener(v -> NavHostFragment.findNavController(ApplicationFragment.this).navigate(R.id.action_nav_application_to_nav_blockly));
        apkbuild.setOnClickListener(v -> NavHostFragment.findNavController(ApplicationFragment.this).navigate(R.id.action_nav_application_to_nav_apkbuild));
        docs.setOnClickListener(v -> NavHostFragment.findNavController(ApplicationFragment.this).navigate(R.id.action_nav_application_to_nav_docs));
        examples.setOnClickListener(v -> NavHostFragment.findNavController(ApplicationFragment.this).navigate(R.id.action_nav_application_to_nav_examples));
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
