package com.shizuku.subsysmgr;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import rikka.shizuku.demo.DemoActivity;

public class Welcome extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        status();
        //skip();
        TextView welcome = findViewById(R.id.welcome_textView);
        welcome.setText(R.string.title_welcome);
        new Handler().postDelayed(() -> {
            welcome.setText(R.string.welcome_aidlux);
            new Handler().postDelayed(() -> {
                PackageInfo aidpackageInfo;
                try {
                    String aidlux_package_name = getString(R.string.aidlux_package);
                    aidpackageInfo = getPackageManager().getPackageInfo(aidlux_package_name, 0);
                } catch (PackageManager.NameNotFoundException e) {
                    aidpackageInfo = null;
                    e.printStackTrace();
                }
                if (aidpackageInfo == null) {
                    aidlux_error();
                } else {
                    welcome.setText(R.string.aidlux_ok);
                    new Handler().postDelayed(() -> {
                        welcome.setText(R.string.welcome_server);
                        new Handler().postDelayed(this::go, 100);
                    }, 100);
                }
            }, 100);
        }, 100);
    }

    private void aidlux_error() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setIcon(R.drawable.ic_baseline_error_red_24)
                .setTitle(R.string.error)
                .setMessage(R.string.aidlux_not)
                .setPositiveButton(R.string.download, (dialog, which) -> aidlux_web())
                .setNeutralButton(R.string.install, ((dialog, which) -> install()))
                .setNegativeButton(R.string.exit, (dialog, which) -> exit())
                .setCancelable(false)
                .create()
                .show();
    }

    private void install() {
        Intent install = new Intent(Welcome.this, DemoActivity.class);
        install.putExtra("intent", "install_apk_s");
        startActivity(install);
        exit();
    }

    private void go() {
        Intent demo = new Intent(Welcome.this, DemoActivity.class);
        demo.putExtra("intent", "welcome");
        startActivity(demo);
        exit();
    }

    private void status() {
        Window window = getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(Color.TRANSPARENT);
    }

    private void aidlux_web() {
        String url = getString(R.string.aidlux_website);
        Uri uri = Uri.parse(url);
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
        exit();
    }

    private void exit() {
        finish();
    }
}