package com.subsysmgr.learnplus;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.aidlux.app.AidluxActivity;
import com.aidlux.usbcamera.USBCameraActivity;
import com.android.vending.AssetBrowserActivity;
import com.google.android.googlequicksearchbox.VoiceSearchActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.shizuku.subsysmgr.R;
import com.shizuku.subsysmgr.databinding.ActivityLearnplusMainBinding;
import com.subsysmgr.learnplus.view.DragFloatActionButton;

import rikka.shizuku.demo.DemoActivity;


public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setNavigationBarColor(getColor(R.color.purple_500));
        com.shizuku.subsysmgr.databinding.ActivityLearnplusMainBinding binding = ActivityLearnplusMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.appBarMainLearnplus.toolbar);
        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;
        mAppBarConfiguration = new AppBarConfiguration.Builder(R.id.nav_manager, R.id.nav_module, R.id.nav_apps, R.id.nav_home, R.id.nav_dashboard, R.id.nav_apps_settings, R.id.nav_application).setOpenableLayout(drawer).build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);
        Toolbar toolbar = findViewById(R.id.toolbar);
        LinearLayout linearLayout = findViewById(R.id.home_ui);
        toolbar.setVisibility(View.GONE);
        linearLayout.setVisibility(View.GONE);
        app_ui_click();
        page();
        status();
        btn();
    }

    private void btn() {
        FloatingActionButton imageButton;
        imageButton = (DragFloatActionButton) findViewById(R.id.fb);
        imageButton.setOnClickListener(v -> app_ui());
    }

    private void toolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        if (toolbar.getVisibility() == View.GONE) {
            toolbar.setVisibility(View.VISIBLE);
        } else {
            toolbar.setVisibility(View.GONE);
        }
    }

    private void navigation(){
        FrameLayout frameLayout = findViewById(R.id.navigation);
        if (frameLayout.getVisibility() == View.GONE) {
            frameLayout.setVisibility(View.VISIBLE);
        }else {
            frameLayout.setVisibility(View.GONE);
        }
    }

    private void app_ui() {
        LinearLayout home = findViewById(R.id.home_ui);
        if (home.getVisibility() == View.GONE) {
            home.setVisibility(View.VISIBLE);
        } else {
            home.setVisibility(View.GONE);
        }
    }

    private void app_ui_click() {
        View view = findViewById(R.id.view);

        Toolbar toolbar = findViewById(R.id.toolbar_home_ui);

        ImageButton toolbar_home_ui_ip = findViewById(R.id.toolbar_home_ui_ip);
        ImageButton toolbar_home_ui_install = findViewById(R.id.toolbar_home_ui_install);
        ImageButton toolbar_home_ui_settings = findViewById(R.id.toolbar_home_ui_settings);
        ImageButton toolbar_home_ui_exit = findViewById(R.id.toolbar_home_ui_exit);

        ImageView app_files = findViewById(R.id.app_files);
        ImageView app_settings = findViewById(R.id.app_settings);
        ImageView app_store = findViewById(R.id.app_store);
        ImageView app_google = findViewById(R.id.app_google);
        ImageView app_launcher = findViewById(R.id.app_launcher);
        ImageView app_camera = findViewById(R.id.app_camera);
        ImageView app_aidlux = findViewById(R.id.app_aidlux);
        ImageView app_apps = findViewById(R.id.app_apps);

        ImageButton imageButton_bottom_apps_files = findViewById(R.id.imageButton_bottom_apps_files);
        ImageButton imageButton_bottom_apps_terminal = findViewById(R.id.imageButton_bottom_apps_terminal);
        ImageButton imageButton_bottom_apps_apps = findViewById(R.id.imageButton_bottom_apps_apps);
        ImageButton imageButton_bottom_apps_webview = findViewById(R.id.imageButton_bottom_apps_webview);
        ImageButton imageButton_bottom_apps_camera = findViewById(R.id.imageButton_bottom_apps_camera);

        Button finish = findViewById(R.id.finish_button);
        Button home = findViewById(R.id.home_button);
        Button manager = findViewById(R.id.mgr_button);

        view.setOnClickListener(v -> navigation());
        view.setOnLongClickListener(v -> {
            app_ui();
            return false;
        });

        toolbar.setNavigationOnClickListener(v -> toolbar());
        toolbar_home_ui_ip.setOnClickListener(v -> {
            NavController cloudip = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            cloudip.navigate(R.id.nav_cloudip);
            app_ui();
        });
        toolbar_home_ui_install.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, DemoActivity.class);
            intent.putExtra("intent", "install_apk_s");
            startActivity(intent);
            app_ui();
        });
        toolbar_home_ui_settings.setOnClickListener(v -> {
            NavController settings = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            settings.navigate(R.id.nav_apps_settings);
            app_ui();
        });
        toolbar_home_ui_exit.setOnClickListener(v -> exit());

        app_files.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, FilesManagerActivity.class));
            app_ui();
        });
        app_settings.setOnClickListener(v -> {
            NavController settings = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            settings.navigate(R.id.nav_apps_settings);
            app_ui();
        });
        app_store.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, AssetBrowserActivity.class));
            app_ui();
        });
        app_google.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, VoiceSearchActivity.class));
            app_ui();
        });
        app_launcher.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, com.tumuyan.fixedplay.MainActivity.class));
            app_ui();
        });
        app_camera.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, USBCameraActivity.class));
            app_ui();
        });
        app_aidlux.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, AidluxActivity.class));
            app_ui();
        });
        app_apps.setOnClickListener(v -> {
            NavController apps = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            apps.navigate(R.id.nav_application);
            app_ui();
        });

        imageButton_bottom_apps_files.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, FilesManagerActivity.class));
            app_ui();
        });
        imageButton_bottom_apps_terminal.setOnClickListener(v -> {
            NavController terminal = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            terminal.navigate(R.id.nav_terminal);
            app_ui();
        });
        imageButton_bottom_apps_apps.setOnClickListener(v -> {
            NavController apps = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            apps.navigate(R.id.nav_application);
            app_ui();
        });
        imageButton_bottom_apps_webview.setOnClickListener(v -> {
            NavController webview = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            webview.navigate(R.id.nav_webview);
            app_ui();
        });
        imageButton_bottom_apps_camera.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, USBCameraActivity.class));
            app_ui();
        });

        finish.setOnClickListener(v -> exit());
        home.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, com.tumuyan.fixedplay.MainActivity.class));
            app_ui();
        });
        manager.setOnClickListener(v -> {
            NavController mgr = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            mgr.navigate(R.id.nav_dashboard);
            app_ui();
        });
    }

    private void page() {
        Intent intent = getIntent();
        String page = intent.getStringExtra("app");
        if (page == null) {
            //弹出提示：意图为空
            Toast.makeText(getApplicationContext(), R.string.intent_null, Toast.LENGTH_SHORT).show();
            //主页
            NavController home = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            home.navigate(R.id.nav_home);
        } else if (page.equals("manager")) {
            //管理器
            NavController manager = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            manager.navigate(R.id.nav_manager);
        } else if (page.equals("module")) {
            //模块
            NavController module = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            module.navigate(R.id.nav_module);
        } else if (page.equals("apps")) {
            //应用(subsysmgr)
            NavController apps = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            apps.navigate(R.id.nav_apps);
        } else if (page.equals("launcher")) {
            //启动主页
            NavController apps = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            apps.navigate(R.id.nav_apps_launcher);
        } else if (page.equals("home")) {
            //主页
            NavController home = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            home.navigate(R.id.nav_home);
        } else if (page.equals("dashboard")) {
            //仪表盘
            NavController dashboard = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            dashboard.navigate(R.id.nav_dashboard);
        } else if (page.equals("terminal")) {
            //终端
            NavController terminal = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            terminal.navigate(R.id.nav_terminal);
        } else if (page.equals("application")) {
            //应用程序
            NavController application = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            application.navigate(R.id.nav_application);
        } else if (page.equals("services")) {
            //服务
            NavController services = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            services.navigate(R.id.nav_settings_aidlux_services);
        } else if (page.equals("webview")) {
            //浏览器
            NavController webview = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            webview.navigate(R.id.nav_webview);
        } else if (page.equals("settings")) {
            //设置
            NavController settings = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            settings.navigate(R.id.nav_apps_settings);
        } else if (page.equals("files")) {
            //文件
            NavController files = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            files.navigate(R.id.nav_apps_files);
        } else if (page.equals("vscode")) {
            //Visual Studio Code
            NavController vscode = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            vscode.navigate(R.id.nav_vscode);
        } else if (page.equals("cloudip")) {
            //云IP
            NavController cloudip = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            cloudip.navigate(R.id.nav_cloudip);
        } else if (page.equals("jupyter")) {
            //笔记
            NavController jupyter = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            jupyter.navigate(R.id.nav_jupyter);
        } else if (page.equals("aidcode")) {
            //aidcode
            NavController aidcode = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            aidcode.navigate(R.id.nav_aidcode);
        } else if (page.equals("blockly")) {
            //blockly
            NavController aidcode = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            aidcode.navigate(R.id.nav_blockly);
        }
        else if (page.equals("apkbuild")) {
            //APK编译
            NavController apkbuild = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            apkbuild.navigate(R.id.nav_apkbuild);
        } else if (page.equals("examples")) {
            //实例中心
            NavController examples = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            examples.navigate(R.id.nav_examples);
        } else if (page.equals("docs")) {
            //开发文档
            NavController docs = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            docs.navigate(R.id.nav_docs);
        } else if (page.equals("xfce")) {
            String url = getString(R.string.xfce);
            String title = getString(R.string.app_xfce);
            Intent intent_xfce = new Intent(MainActivity.this, DesktopActivity.class);
            intent_xfce.putExtra("url", url);
            intent_xfce.putExtra("title", title);
            startActivity(intent_xfce);
        } else {
            //弹出提示：未知意图
            Toast.makeText(getApplicationContext(), R.string.intent_unknown, Toast.LENGTH_SHORT).show();
            //主页
            NavController home = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            home.navigate(R.id.nav_home);
        }
    }

    private void status() {
        Intent intent = getIntent();
        String status = intent.getStringExtra("status");
        if (status != null) {
            String ok = getString(R.string.sure);
            String log = getString(R.string.services_log);
            Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), log + status, Snackbar.LENGTH_INDEFINITE);
            snackbar.setAction(ok, view -> {
            });
            snackbar.show();
        }
    }

    private void exit() {
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            NavController settings = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            settings.navigate(R.id.nav_apps_settings);
            return true;
        } else if (id == R.id.action_store) {
            startActivity(new Intent(MainActivity.this, AssetBrowserActivity.class));
            return true;
        } else if (id == R.id.action_google) {
            startActivity(new Intent(MainActivity.this, VoiceSearchActivity.class));
            return true;
        } else if (id == R.id.action_aidlux) {
            startActivity(new Intent(MainActivity.this, AidluxActivity.class));
            return true;
        } else if (id == R.id.action_camera) {
            startActivity(new Intent(MainActivity.this, USBCameraActivity.class));
            return true;
        } else if (id == R.id.action_launcher) {
            startActivity(new Intent(MainActivity.this, com.tumuyan.fixedplay.MainActivity.class));
            return true;
        } else if (id == R.id.action_files) {
            startActivity(new Intent(MainActivity.this, FilesManagerActivity.class));
            return true;
        } else if (id == R.id.action_install) {
            Intent intent = new Intent(MainActivity.this, DemoActivity.class);
            intent.putExtra("intent", "install_apk_s");
            startActivity(intent);
            return true;
        } else if (id == R.id.action_docs) {
            NavController docs = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            docs.navigate(R.id.nav_docs);
            return true;
        } else if (id == R.id.action_examples) {
            NavController examples = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            examples.navigate(R.id.nav_examples);
            return true;
        } else if (id == R.id.action_ip) {
            NavController cloudip = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            cloudip.navigate(R.id.nav_cloudip);
            return true;
        } else if (id == R.id.action_exit) {
            exit();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }
}