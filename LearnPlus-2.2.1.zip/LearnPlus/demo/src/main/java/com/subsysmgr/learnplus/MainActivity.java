package com.subsysmgr.learnplus;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.navigation.NavigationView;
import com.shizuku.subsysmgr.R;
import com.shizuku.subsysmgr.databinding.ActivityLearnplusMainBinding;


public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setNavigationBarColor(getColor(R.color.purple_500));
        com.shizuku.subsysmgr.databinding.ActivityLearnplusMainBinding binding = ActivityLearnplusMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.appBarMainLearnplus.toolbar);
        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;
        mAppBarConfiguration = new AppBarConfiguration.Builder(R.id.nav_manager, R.id.nav_module, R.id.nav_apps, R.id.nav_home, R.id.nav_dashboard, R.id.nav_apps_settings, R.id.nav_application).setOpenableLayout(drawer).build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);
        page();
    }

    private void page() {
        Intent intent = getIntent();
        String page = intent.getStringExtra("app");
        if (page == null) {
            //弹出提示：意图为空
            Toast.makeText(getApplicationContext(), R.string.intent_null, Toast.LENGTH_SHORT).show();
        } else if (page.equals("manager")) {
            //管理器
            NavController manager = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            manager.navigate(R.id.nav_manager);
        } else if (page.equals("module")) {
            //模块
            NavController module = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            module.navigate(R.id.nav_module);
        } else if (page.equals("apps")) {
            //应用(subsysmgr)
            NavController apps = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            apps.navigate(R.id.nav_apps);
        } else if (page.equals("launcher")) {
            //启动主页
            NavController apps = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            apps.navigate(R.id.nav_apps_launcher);
        } else if (page.equals("home")) {
            //主页
            NavController home = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            home.navigate(R.id.nav_home);
        } else if (page.equals("dashboard")) {
            //仪表盘
            NavController dashboard = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            dashboard.navigate(R.id.nav_dashboard);
        } else if (page.equals("terminal")) {
            //终端
            NavController terminal = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            terminal.navigate(R.id.nav_terminal);
        } else if (page.equals("application")) {
            //应用程序
            NavController application = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            application.navigate(R.id.nav_application);
        } else if (page.equals("services")) {
            //服务
            NavController services = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            services.navigate(R.id.nav_settings_aidlux_services);
        } else if (page.equals("webview")) {
            //浏览器
            NavController webview = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            webview.navigate(R.id.nav_webview);
        } else if (page.equals("settings")) {
            //设置
            NavController settings = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            settings.navigate(R.id.nav_apps_settings);
        } else if (page.equals("files")) {
            //文件
            NavController files = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            files.navigate(R.id.nav_apps_files);
        } else if (page.equals("vscode")) {
            //Visual Studio Code
            NavController vscode = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            vscode.navigate(R.id.nav_vscode);
        } else if (page.equals("cloudip")) {
            //云IP
            NavController cloudip = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            cloudip.navigate(R.id.nav_cloudip);
        } else if (page.equals("jupyter")) {
            //笔记
            NavController jupyter = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            jupyter.navigate(R.id.nav_jupyter);
        } else if (page.equals("aidcode")) {
            //aidcode
            NavController aidcode = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            aidcode.navigate(R.id.nav_aidcode);
        } else if (page.equals("blockly")) {
            //积木编程
            NavController blockly = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            blockly.navigate(R.id.nav_blockly);
        } else if (page.equals("apkbuild")) {
            //APK编译
            NavController apkbuild = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            apkbuild.navigate(R.id.nav_apkbuild);
        } else if (page.equals("examples")) {
            //实例中心
            NavController examples = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            examples.navigate(R.id.nav_examples);
        } else if (page.equals("docs")) {
            //开发文档
            NavController docs = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
            docs.navigate(R.id.nav_docs);
        } else {
            //弹出提示：未知意图
            Toast.makeText(getApplicationContext(), R.string.intent_unknown, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_learnplus);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }
}