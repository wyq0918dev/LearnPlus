package android.content;

public class Intent {

}
