package com.subsysmgr.learnplus.ui.module;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Switch;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.shizuku.subsysmgr.R;
import com.shizuku.subsysmgr.databinding.FragmentModuleBinding;


public class ModuleFragment extends Fragment {

    private FragmentModuleBinding binding;

    @SuppressLint("UseSwitchCompatOrMaterialCode")
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentModuleBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final CardView app = binding.module;
        final Switch checkbox = binding.checkbox;

        app.setOnClickListener(v -> app());
        checkbox.setChecked(true);
        checkbox.setSwitchTextAppearance(getActivity(), R.style.s_false);
        checkbox.setOnCheckedChangeListener((compoundButton, b) -> {
            if (b) {
                checkbox.setSwitchTextAppearance(getActivity(), R.style.s_true);
            } else {
                checkbox.setSwitchTextAppearance(getActivity(), R.style.s_false);
            }
        });
        checkbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                app();
            } else {
                stop();
            }
        });

        return root;
    }

    private void stop() {
        NavHostFragment.findNavController(ModuleFragment.this).navigate(R.id.action_nav_module_to_nav_manager);
    }

    private void app() {
        NavHostFragment.findNavController(ModuleFragment.this).navigate(R.id.action_nav_module_to_nav_apps_launcher);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}