package com.subsysmgr.learnplus.ui.settings;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.android.settings.applications.DefaultAppSelectionActivity;
import com.android.settings.system.Settings;
import com.android.subsysmgr.UninstallActivity;
import com.shizuku.subsysmgr.R;
import com.shizuku.subsysmgr.databinding.FragmentAppsSettingsBinding;
import com.tumuyan.fixedplay.SettingActivity;

import rikka.shizuku.demo.DemoActivity;

public class SettingsFragment extends Fragment {

    private FragmentAppsSettingsBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentAppsSettingsBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        //初始化控件
        final Button select_launcher = binding.button1;
        final Button select_app = binding.button2;
        final Button install_apk = binding.buttonInstallApkS;
        final Button abandon_all_my_installer_sessions = binding.buttonAbandonAllMyInstallerSessions;
        final Button bind_user_service = binding.buttonBindUserService;
        final Button unbind_user_service = binding.buttonUnbindUserService;
        final CardView subsysmgr_settings_system = binding.subsysmgrSettingsSystem;
        final CardView subsysmgr_settings_home = binding.subsysmgrSettingsHome;
        final CardView subsysmgr_settings_uninstall = binding.subsysmgrSettingsUninstall;

        //设置传递选择应用的事件
        Intent intent_select_app = new Intent(getActivity(), SettingActivity.class);
        intent_select_app.putExtra("setting","select_app");

        //设置传递安装APK的事件
        Intent intent_install_apk_s = new Intent(getActivity(), DemoActivity.class);
        intent_install_apk_s.putExtra("intent", "install_apk_s");

        //设置传递放弃所有安装程序会话的事件
        Intent intent_abandon_all_my_installer_sessions = new Intent(getActivity(), DemoActivity.class);
        intent_abandon_all_my_installer_sessions.putExtra("intent", "abandon_all_my_installer_sessions");

        //设置传递绑定用户服务的事件
        Intent intent_binduserservice = new Intent(getActivity(), DemoActivity.class);
        intent_binduserservice.putExtra("intent", "binduserservice");

        //设置传递解绑用户服务的事件
        Intent intent_unbinduserservice = new Intent(getActivity(), DemoActivity.class);
        intent_unbinduserservice.putExtra("intent", "unbinduserservice");

        //控件点击事件
        select_launcher.setOnClickListener(v -> startActivity(new Intent(getActivity(), DefaultAppSelectionActivity.class)));
        select_app.setOnClickListener(v -> startActivity(intent_select_app));
        install_apk.setOnClickListener(v -> startActivity(intent_install_apk_s));
        abandon_all_my_installer_sessions.setOnClickListener(v -> startActivity(intent_abandon_all_my_installer_sessions));
        bind_user_service.setOnClickListener(v -> startActivity(intent_binduserservice));
        unbind_user_service.setOnClickListener(v -> startActivity(intent_unbinduserservice));
        subsysmgr_settings_system.setOnClickListener(v -> startActivity(new Intent(getActivity(), Settings.class)));
        subsysmgr_settings_home.setOnClickListener(v -> startActivity(new Intent(getActivity(), DefaultAppSelectionActivity.class)));
        subsysmgr_settings_uninstall.setOnClickListener(v -> startActivity(new Intent(getActivity(), UninstallActivity.class)));

        return root;
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        final CardView subsysmgr_settings_services = binding.subsysmgrSettingsServices;
        final CardView subsysmgr_settings_app = binding.subsysmgrSettingsApp;
        subsysmgr_settings_services.setOnClickListener(v -> NavHostFragment.findNavController(SettingsFragment.this).navigate(R.id.action_nav_apps_settings_to_nav_settings_aidlux_services));
        subsysmgr_settings_app.setOnClickListener(v -> NavHostFragment.findNavController(SettingsFragment.this).navigate(R.id.action_nav_apps_settings_to_nav_home));
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
