package com.subsysmgr.learnplus;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.android.settings.Settings;
import com.shizuku.subsysmgr.R;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        Toolbar toolbar = findViewById(R.id.toolbar);
        View system_settings = findViewById(R.id.system_settings);
        View aid_settings = findViewById(R.id.aid_settings);
        View app_settings = findViewById(R.id.app_settings);

        toolbar.setNavigationOnClickListener(v -> finish());
        system_settings.setOnClickListener(v -> startActivity(new Intent(SettingsActivity.this, Settings.class)));
        aid_settings.setOnClickListener(v -> startActivity(new Intent(SettingsActivity.this, com.android.settings.subsystem.SettingsActivity.class)));
        app_settings.setOnClickListener(v -> startActivity(new Intent(SettingsActivity.this, com.android.settings.subsysmgr.SettingsActivity.class)));
    }
}