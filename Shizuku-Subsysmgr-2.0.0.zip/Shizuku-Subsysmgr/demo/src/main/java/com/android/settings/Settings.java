package com.android.settings;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.android.settings.applications.DefaultAppSelectionActivity;
import com.shizuku.subsysmgr.R;

public class Settings extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        View setting_system = findViewById(R.id.settings_system);
        View setting_default = findViewById(R.id.settings_default);

        setting_system.setOnClickListener(v -> startActivity(new Intent(Settings.this, com.android.settings.system.Settings.class)));
        setting_default.setOnClickListener(v -> startActivity(new Intent(Settings.this, DefaultAppSelectionActivity.class)));
    }
}