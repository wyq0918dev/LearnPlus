package com.android.settings.subsysmgr;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.android.subsysmgr.UninstallActivity;
import com.shizuku.subsysmgr.R;
import com.tumuyan.fixedplay.SettingActivity;

import rikka.shizuku.demo.DemoActivity;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_settings);
        //Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        View launcher = findViewById(R.id.settings_anylauncher);
        View demo = findViewById(R.id.settings_install);
        View un = findViewById(R.id.settings_uninstall);

        launcher.setOnClickListener(v -> startActivity(new Intent(SettingsActivity.this, SettingActivity.class)));
        demo.setOnClickListener(v -> startActivity(new Intent(SettingsActivity.this, DemoActivity.class)));
        un.setOnClickListener(v -> startActivity(new Intent(SettingsActivity.this, UninstallActivity.class)));
    }
}