package com.subsysmgr.learnplus.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.aidlux.app.AidluxActivity;
import com.aidlux.usbcamera.USBCameraActivity;
import com.android.vending.AssetBrowserActivity;
import com.google.android.googlequicksearchbox.VoiceSearchActivity;
import com.shizuku.subsysmgr.R;
import com.shizuku.subsysmgr.databinding.FragmentHomeBinding;
import com.subsysmgr.learnplus.FilesManagerActivity;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        ImageView app_files = binding.appFiles;
        ImageView app_store = binding.appStore;
        ImageView app_google = binding.appGoogle;
        ImageView app_launcher = binding.appLauncher;
        ImageView app_camera = binding.appCamera;
        ImageView app_aidlux = binding.appAidlux;
        ImageView imageButton_bottom_apps_files = binding.imageButtonBottomAppsFiles;
        ImageView imageButton_bottom_apps_camera = binding.imageButtonBottomAppsCamera;

        app_files.setOnClickListener(v -> startActivity(new Intent(getActivity(), FilesManagerActivity.class)));
        app_store.setOnClickListener(v -> startActivity(new Intent(getActivity(), AssetBrowserActivity.class)));
        app_google.setOnClickListener(v -> startActivity(new Intent(getActivity(), VoiceSearchActivity.class)));
        app_launcher.setOnClickListener(v -> startActivity(new Intent(getActivity(), com.tumuyan.fixedplay.MainActivity.class)));
        app_camera.setOnClickListener(v -> startActivity(new Intent(getActivity(), USBCameraActivity.class)));
        app_aidlux.setOnClickListener(v -> startActivity(new Intent(getActivity(), AidluxActivity.class)));
        imageButton_bottom_apps_files.setOnClickListener(v -> startActivity(new Intent(getActivity(), FilesManagerActivity.class)));
        imageButton_bottom_apps_camera.setOnClickListener(v -> startActivity(new Intent(getActivity(), USBCameraActivity.class)));

        return root;
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ImageView app = binding.appApps;
        ImageView imagebutton_bottom_apps_terminal = binding.imageButtonBottomAppsTerminal;
        ImageView imageButton_bottom_apps_apps = binding.imageButtonBottomAppsApps;
        ImageView webview = binding.imageButtonBottomAppsWebview;
        ImageView settings = binding.appSettings;
        app.setOnClickListener(v -> NavHostFragment.findNavController(HomeFragment.this).navigate(R.id.action_nav_home_to_nav_application));
        imagebutton_bottom_apps_terminal.setOnClickListener(v -> NavHostFragment.findNavController(HomeFragment.this).navigate(R.id.action_nav_home_to_nav_terminal));
        webview.setOnClickListener(v -> NavHostFragment.findNavController(HomeFragment.this).navigate(R.id.action_nav_home_to_nav_webview));
        settings.setOnClickListener(v -> NavHostFragment.findNavController(HomeFragment.this).navigate(R.id.action_nav_home_to_nav_apps_settings));
        imageButton_bottom_apps_apps.setOnClickListener(v -> NavHostFragment.findNavController(HomeFragment.this).navigate(R.id.action_nav_home_to_nav_application));
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}