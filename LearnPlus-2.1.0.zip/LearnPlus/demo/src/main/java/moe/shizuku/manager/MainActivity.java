package moe.shizuku.manager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ComponentName apk2Component1 = new ComponentName("moe.shizuku.privileged.api", "moe.shizuku.manager.MainActivity");
        Intent mIntent = new Intent();
        mIntent.addCategory(Intent.CATEGORY_LAUNCHER);
        mIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        mIntent.setComponent(apk2Component1);
        startActivity(mIntent);
        finish();
    }
}