package com.subsysmgr.learnplus;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.shizuku.subsysmgr.R;

public class Welcome extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        TextView welcome = findViewById(R.id.welcome_textView);
        welcome.setText(R.string.title_welcome);
        new Handler().postDelayed(() -> {
            welcome.setText(R.string.welcome_shizuku);
            new Handler().postDelayed(() -> {
                PackageInfo packageInfo;
                try {
                    packageInfo = this.getPackageManager().getPackageInfo("moe.shizuku.privileged.api", 0);
                } catch (PackageManager.NameNotFoundException e) {
                    packageInfo = null;
                    e.printStackTrace();
                }
                if (packageInfo == null) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setIcon(R.drawable.ic_baseline_error_24)
                            .setTitle(R.string.error)
                            .setMessage(R.string.shizuku_not)
                            .setPositiveButton(R.string.welcome_install_shizuku, (dialog, which) -> {
                                Uri uri = Uri.parse("https://shizuku.rikka.app");
                                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                                startActivity(intent);
                                finish();
                            })
                            .setNegativeButton(R.string.exit, (dialog, which) -> finish())
                            .setCancelable(false)
                            .create()
                            .show();
                } else {
                    welcome.setText(R.string.shizuku_ok);
                    new Handler().postDelayed(() -> {
                        welcome.setText(R.string.welcome_aidlux);
                        new Handler().postDelayed(() -> {
                            PackageInfo aidpackageInfo;
                            try {
                                aidpackageInfo = getPackageManager().getPackageInfo("com.aidlux", 0);
                            } catch (PackageManager.NameNotFoundException e) {
                                aidpackageInfo = null;
                                e.printStackTrace();
                            }
                            if (aidpackageInfo == null) {
                                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                                builder.setIcon(R.drawable.ic_baseline_error_24)
                                        .setTitle(R.string.error)
                                        .setMessage(R.string.aidlux_not)
                                        .setPositiveButton(R.string.welcome_install_aidlux, (dialog, which) -> {
                                            Uri uri = Uri.parse("https://www.aidlearning.net");
                                            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                                            startActivity(intent);
                                            finish();
                                        })
                                        .setNegativeButton(R.string.exit, (dialog, which) -> finish())
                                        .setCancelable(false)
                                        .create()
                                        .show();
                            } else {
                                welcome.setText(R.string.aidlux_ok);
                                new Handler().postDelayed(() -> {
                                    welcome.setText(R.string.ok);
                                    new Handler().postDelayed(() -> {
                                        startActivity(new Intent(Welcome.this, MainActivity.class));
                                        finish();
                                    }, 1000);
                                }, 1000);
                            }
                        }, 1000);
                    }, 1000);
                }
            }, 1000);
        }, 1000);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            View decorView = getWindow().getDecorView();
            decorView.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }
}