package com.subsysmgr.learnplus.ui.dashboard;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.android.settings.applications.DeviceInfoActivity;
import com.shizuku.subsysmgr.R;
import com.shizuku.subsysmgr.databinding.FragmentDashboardBinding;

public class DashboardFragment extends Fragment {


    private FragmentDashboardBinding binding;

    @SuppressLint("UseCompatLoadingForDrawables")
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentDashboardBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final TextView textView_status = binding.textViewStatus;
        final TextView subsysmgr_version = binding.subsysmgrVersion;
        final TextView ic_manufacturer = binding.icManufacturer;
        final TextView cpu = binding.cpu;
        final ImageView imageView_status = binding.imageViewStatus;
        final View device = binding.device;

        @SuppressLint("UseSwitchCompatOrMaterialCode") final Switch switch_status;
        switch_status = binding.switchStatus;
        switch_status.setChecked(true);
        switch_status.setSwitchTextAppearance(getActivity(),R.style.s_false);
        switch_status.setOnCheckedChangeListener((compoundButton, b) -> {
            if (b) {
                switch_status.setSwitchTextAppearance(getActivity(), R.style.s_true);
            }else {
                switch_status.setSwitchTextAppearance(getActivity(), R.style.s_false);
            }
        });

        switch_status.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked){
                textView_status.setText(R.string.lp_framework_active);
                subsysmgr_version.setText(R.string.app_name);
                ic_manufacturer.setText(R.string.manufacturer);
                cpu.setText(R.string.cpu);
                textView_status.setTextColor(getResources().getColor(R.color.darker_green));
                imageView_status.setBackgroundColor(getResources().getColor(R.color.darker_green));
                imageView_status.setImageDrawable(getResources().getDrawable(R.drawable.ic_baseline_check_circle_outline_24));
            }else {
                textView_status.setText(R.string.lp_framework_not_activated);
                subsysmgr_version.setText(R.string.unknow);
                ic_manufacturer.setText(R.string.unknow);
                cpu.setText(R.string.unknow);
                textView_status.setTextColor(getResources().getColor(R.color.amber_500));
                imageView_status.setBackgroundColor(getResources().getColor(R.color.amber_500));
                imageView_status.setImageDrawable(getResources().getDrawable(R.drawable.ic_baseline_warning_24));
            }
        });

        device.setOnClickListener(v -> startActivity(new Intent(getActivity(), DeviceInfoActivity.class)));

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}