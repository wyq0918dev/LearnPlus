package com.subsysmgr.learnplus.ui.terminal;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.aidlux.app.AidluxActivity;
import com.android.subsysmgr.MainActivity;
import com.shizuku.subsysmgr.databinding.FragmentTerminalBinding;


public class TerminalFragment extends Fragment {


    private FragmentTerminalBinding binding;

    @SuppressLint("SetJavaScriptEnabled")
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentTerminalBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final WebView terminal = binding.novnc;
        terminal.getSettings().setJavaScriptEnabled(true);
        terminal.getSettings().setDatabaseEnabled(true);
        terminal.getSettings().setDomStorageEnabled(true);
        terminal.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
        terminal.getSettings().setUseWideViewPort(true);
        terminal.getSettings().setLoadWithOverviewMode(true);
        terminal.getSettings().setSupportZoom(true);
        terminal.getSettings().setBuiltInZoomControls(true);
        terminal.getSettings().setDisplayZoomControls(false);
        terminal.getSettings().setAppCacheEnabled(true);
        terminal.requestFocus();
        terminal.setWebViewClient(new WebViewClient());
        terminal.loadUrl("file:///android_asset/index.htm");

        final ImageButton mgr = binding.mgrImageButton;
        final ImageButton app = binding.appsImageButton;
        final ImageButton web = binding.aidWebImageButton;

        mgr.setOnClickListener(v -> startActivity(new Intent(getActivity(), MainActivity.class)));
        app.setOnClickListener(v -> startActivity(new Intent(getActivity(), com.android.launcher3.applications.MainActivity.class)));
        web.setOnClickListener(v -> startActivity(new Intent(getActivity(), AidluxActivity.class)));

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}