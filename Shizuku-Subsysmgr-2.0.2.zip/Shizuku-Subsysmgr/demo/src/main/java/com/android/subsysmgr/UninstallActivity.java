package com.android.subsysmgr;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

public class UninstallActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Uri packageUri = Uri.parse("package:"+UninstallActivity.this.getPackageName());
        Intent uninstall_intent = new Intent(Intent.ACTION_DELETE,packageUri);
        startActivity(uninstall_intent);
        finish();
    }
}