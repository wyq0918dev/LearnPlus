package com.subsysmgr.learnplus.ui.launcher;

import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.shizuku.subsysmgr.R;
import com.shizuku.subsysmgr.databinding.FragmentLauncherBinding;

public class LauncherFragment extends Fragment {

    private FragmentLauncherBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentLauncherBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        ProgressBar progressBar = binding.progressbarStartApp;
        TextView textView = binding.textView;

        new Handler().postDelayed(() -> {
            int progress = progressBar.getProgress();
            progress += 20;
            progressBar.setProgress(progress);
            new Handler().postDelayed(() -> {
                int progress2 = progressBar.getProgress();
                progress2 += 20;
                progressBar.setProgress(progress2);
                new Handler().postDelayed(() -> {
                    int progress3 = progressBar.getProgress();
                    progress3 += 20;
                    progressBar.setProgress(progress3);
                    new Handler().postDelayed(() -> {
                        int progress4 = progressBar.getProgress();
                        progress4 += 20;
                        progressBar.setProgress(progress4);
                        new Handler().postDelayed(() -> {
                            int progress5 = progressBar.getProgress();
                            progress5 += 20;
                            progressBar.setProgress(progress5);
                            textView.setText(R.string.ok);
                            new Handler().postDelayed(this::go, 100);
                        }, 100);
                    }, 100);
                }, 100);
            }, 100);
        }, 100);
        return root;
    }

    private void go() {
        NavHostFragment.findNavController(LauncherFragment.this).navigate(R.id.action_nav_apps_launcher_to_nav_home);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}